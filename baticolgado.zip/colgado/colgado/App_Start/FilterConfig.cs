﻿using System.Web;
using System.Web.Mvc;

namespace colgado
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            //Filtro para hacer privado el sistema (todo)
            filters.Add(new AuthorizeAttribute());
        }
    }
}