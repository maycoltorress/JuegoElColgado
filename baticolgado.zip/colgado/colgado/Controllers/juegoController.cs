﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using colgado.Models;

namespace colgado.Controllers
{
    public class juegoController : Controller
    {
        private colgadoEntities1 db = new colgadoEntities1();
        static int puntaje = 0;
        //
        // GET: /juego/

        public ActionResult Index()
        {
            return View(db.juego.ToList());
        }

        //
        // GET: /juego/Details/5

        public ActionResult Details(int id = 0)
        {
            juego juego = db.juego.Find(id);
            if (juego == null)
            {
                return HttpNotFound();
            }
            return View(juego);
        }

        //
        // GET: /juego/Create

        public ActionResult Create(int p)
        {
            puntaje = p;
            ViewBag.puntaje = puntaje;
            return View();
        }

        //
        // POST: /juego/Create

        [HttpPost]
        public ActionResult Create(juego juego, string nombre)
        { 

            juego.juego_puntaje = puntaje;
            juego.juego_nombre = nombre;
            if (ModelState.IsValid)
            {
                db.juego.Add(juego);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(juego);
        }

        //
        // GET: /juego/Edit/5

        public ActionResult Edit(int id = 0)
        {
            juego juego = db.juego.Find(id);
            if (juego == null)
            {
                return HttpNotFound();
            }
            return View(juego);
        }

        //
        // POST: /juego/Edit/5

        [HttpPost]
        public ActionResult Edit(juego juego)
        {
            if (ModelState.IsValid)
            {
                db.Entry(juego).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(juego);
        }

        //
        // GET: /juego/Delete/5

        public ActionResult Delete(int id = 0)
        {
            juego juego = db.juego.Find(id);
            if (juego == null)
            {
                return HttpNotFound();
            }
            return View(juego);
        }

        //
        // POST: /juego/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            juego juego = db.juego.Find(id);
            db.juego.Remove(juego);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}