﻿using colgado.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace colgado.Controllers
{
    public class HomeController : Controller
    {
        static string palabra, mensaje, indices;
        static string[] arreglo;
        static int[] binario;
        static int i = -1;
        static int lineas;
        static int largo;
        static int ganar = 0;
        static int puntaje = 0;
        static int intentos = 4;
        static int palabrasEncontradas = 0;
        static bool win = false;
        static ArrayList a;
        MiObjeto obj = new MiObjeto();
        //
        // GET: /Home/

        [HttpGet]
        public ActionResult Index(string b)
        {
            if (b == "1")//Si estoy accionando el actionlink de juego
            {
                i = -1;//volver a iniciar las variables
                ganar = 0;
                puntaje = 0;
                intentos = 4;
                win = false;
                palabrasEncontradas = 0;
                lineas = 0;

            }
            if (i == -1)//si ejecuto por primera vez
            {
                a = new ArrayList();
                lineas = obj.ContarLineas();
                a = obj.generar(); //Recibir el arraylist con indices desordenados sin repetir
            }

            i++;
            if (i < lineas)
            {
                mensaje = "";
                ganar = 0;
                indices = "";

                int x = Convert.ToInt32(a[i]); //obtener el elemento del arraylist
                palabra = obj.leer(x);         //leer la palabra segun la linea que me entregue el arraylist
                ViewBag.palabra = palabra;
                largo = palabra.Length;
                arreglo = new string[largo]; //declarar el largo del arreglo
                binario = new int[largo];

                mensaje += palabra.Substring(0, 1);
                for (int j = 1; j < largo - 1; j++) //llenar el mensaje para mostrarlo por interfaz a_ _ b
                {
                    mensaje += " _ ";
                }
                mensaje += palabra.Substring(largo - 1, 1);//(4,1)

                ViewBag.mensaje = mensaje;
                ViewBag.i = i;
                ViewBag.largo = largo;
                ViewBag.puntaje = puntaje;
                ViewBag.lineas = lineas;
                ViewBag.intentos = intentos;

                for (int j = 0; j < largo; j++)//llenar el arreglo con caracteres para luego sobreescribirlo
                {
                    arreglo[j] = " _ ";
                }

                for (int j = 0; j < a.Count; j++)//mostrar el orden en que se mostraran las lineas
                {
                    indices += a[j] + " - ";
                }
                ViewBag.indices = indices;
            }
            return View();
        }

        [HttpPost]
        public ActionResult Index(string button, string texbox, long id=0)
        {

            if (i < lineas)
            {
                
                int valor = obj.BuscarLetra(palabra, texbox, largo); //buscar la letra en la palabra
                if (valor != -1)
                {
                    arreglo[0] = palabra.Substring(0, 1);
                    binario[0] = 1;
                    for (int j = 1; j < largo - 1; j++)
                    {
                        if (j == valor)
                        {
                            for (int k = 1; k < largo - 1; k++) //recorrer la palabra para encontrar la misma letra varias veces si esta repetida
                            {
                                if (texbox.Equals(palabra.Substring(k, 1)) && binario[k] == 0) //si esta repetida pero no mostrada aun almaceno un 1 en el arreglo binario
                                {
                                    arreglo[k] = palabra.Substring(k, 1);
                                    ganar++;
                                    binario[k] = 1;
                                    if (ganar == largo - 2)// si he encontrado todas las palabras
                                    {
                                        puntaje += 10;
                                        palabrasEncontradas++;
                                        if (palabrasEncontradas == lineas)
                                        {
                                            win = true;
                                            return RedirectToAction("Inicio");
                                        }
                                        return RedirectToAction("Index");
                                    }
                                }
                                else
                                {
                                    if (texbox.Equals(palabra.Substring(k, 1)) && binario[k] == 1) // si la letra que estoy ingresando ya esta presente en la palabra
                                        ViewBag.fail = "Letra repetida";
                                }
                            }
                        }

                    }
                    arreglo[largo - 1] = palabra.Substring(largo - 1, 1);//ultima letra
                    mensaje = "";
                    for (int j = 0; j < largo; j++)
                    {
                        mensaje += arreglo[j];
                    }
                }
                else
                {
                    ViewBag.fail = "La letra buscada no esta en la palabra";
                    intentos--;
                    if (intentos == 0)
                    {
                        return RedirectToAction("Inicio");//si pierde lo redirecciono a otra pagina
                    }

                }
                ViewBag.mensaje = mensaje;
                //ViewBag.arreglo = a[0] + " " + a[1] + " " + a[2];
                ViewBag.i = i;
                ViewBag.palabra = palabra;
                ViewBag.largo = largo;
                ViewBag.puntaje = puntaje;
                ViewBag.lineas = lineas;
                ViewBag.intentos = intentos;
                ViewBag.indices = indices;
            }


            return View();
        }
        [HttpGet]
        public ActionResult Inicio()
        {
            if (win == true)//si entontro a todas las palabras
            {
                ViewBag.mensaje = "Felicidades encontraste todas las palabras, puntaje final: " + puntaje;
                
            }
            else
                ViewBag.mensaje = "¡Lo sentimos! ha perdido, puntaje final: " + puntaje;

            return View();
        }

        [HttpPost]
        public ActionResult Inicio(/*long id = 0,*/string button)
        {
            if (button == "Volver a jugar")
            {
                i = -1;//volver a iniciar las variables
                ganar = 0;
                puntaje = 0;
                intentos = 4;
                win = false;
                palabrasEncontradas = 0;
                lineas = 0;
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Create", "juego", new { p = puntaje });
            }
        }

        [AllowAnonymous]
        public ActionResult About()
        {
            ViewBag.Message = "Página de descripción de la aplicación.";

            return View();
        }
        [AllowAnonymous]
        public ActionResult Contact()
        {
            ViewBag.Message = "Página de contacto.";

            return View();
        }
    }
}
