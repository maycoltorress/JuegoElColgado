﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace colgado.Models
{
    public class MiObjeto
    {
        public int palabra { get; set; }

        static int cont = 0;
        int n;
        static int[] indice;
        ArrayList a = new ArrayList();
        Random r = new Random();


        public int ContarLineas()
        {
            cont = 0;
            string line;
            //Read the file and display it line by line.
            System.IO.StreamReader file = new System.IO.StreamReader(@"c:\progra.txt");
            while ((line = file.ReadLine()) != null)
            {
                cont++;
            }
            file.Close();
            indice = new int[cont];
            return cont;
        }

        public string leer(int i)
        {
            cont = 0;
            string line;
            string mensaje = "";

            //Read the file and display it line by line.
            System.IO.StreamReader file = new System.IO.StreamReader(@"c:\progra.txt");
            while ((line = file.ReadLine()) != null)
            {
                if (cont == i)
                {
                    mensaje += line;
                    return mensaje;
                }
                System.Console.WriteLine(line);
                //mensaje += line;
                cont++;
            }

            file.Close();
            //System.Console.WriteLine("There were {0} lines.", counter);
            //// Suspend the screen.
            //System.Console.ReadLine();

            return mensaje;
        }

        //Buscar el numero (linea) en el arreglo
        public int buscar(int[] indice, int n)
        {
            for (int i = 0; i < cont; i++)
            {
                if (indice[i] == n)
                    return 1;
            }
            return 0;
        }


        //Generar valores alterorios de indice sin repetir
        public ArrayList generar()
        {
            //llenar arreglo con -1
            for (int i = 0; i < cont; i++)
            {
                indice[i] = -1;
            }

            for (int i = 0; i < cont; i++)
            {
                n = r.Next(0, cont);
                int respuesta = buscar(indice, n);
                if (respuesta == 1)
                    i--;
                else
                    indice[i] = n;

            }

            for (int i = 0; i < cont; i++)
            {
                a.Add(indice[i]);
            }
            return a;
        }

        public int BuscarLetra(string palabra, string letra, int largo)
        {
            for (int i = 1; i < largo - 1; i++)
            {
                if (letra.Equals(palabra.Substring(i, 1)))
                    return i;
            }
            return -1;
        }

    }
}